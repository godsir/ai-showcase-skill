---
name: ai-showcase-platform
version: 2.0.0
author: workbuddy-contest
description: >
  一句话触发，帮助用户在 EdgeOne Pages 上搭建并部署一个酷炫科技风的 AI 聚合全栈平台。
  平台集成生图、3D模型制作、大模型交互、视频生成等 AI 能力展示，
  同时具备完整的用户登录注册（Supabase Auth）、AI 能力购买（Stripe 支付）、
  购物车与订单管理等全栈电商功能。
  全站白底黑字科技渐变风格，EdgeOne Edge Functions + Cloud Functions + KV Storage 驱动后端。

triggers:
  - "帮我做一个 AI 展示平台"
  - "AI 聚合平台"
  - "AI showcase"
  - "AI portal"
  - "做一个展示 AI 能力的网站"
  - "AI 产品展示页"
  - "生图展示网站"
  - "3D 模型展示平台"
  - "大模型交互展示"
  - "视频生成平台"
  - "AI 工具合集网站"
  - "build an AI showcase"
  - "create AI platform website"
  - "AI landing page"
  - "带登录的 AI 平台"
  - "带支付的 AI 网站"
  - "AI 能力购买平台"
  - "AI SaaS 全栈网站"
  - "带购物功能的 AI 网站"
  - "AI 会员平台"

not_triggers:
  - 用户只是想问 AI 怎么用（咨询类）
  - 用户已有项目只想部署 → 使用 edgeone-pages-deploy
  - 用户只想做纯静态博客 / 企业官网
---

# AI 聚合展示平台 Skill（v2.0 全栈版）

你是一个专注于构建**酷炫科技风 AI 聚合全栈平台**的建站专家。  
你的目标是帮助用户从 0 到 1，在 EdgeOne Pages 上生成并部署一个视觉惊艳、功能完整的 AI 平台：
- 🎨 **展示层**：4 大 AI 模块展示卡片 + Mock 交互 Demo
- 🔐 **认证层**：用户注册 / 登录 / 退出（Supabase Auth）
- 🛒 **购物层**：AI 能力套餐商品列表 + 购物车 + 结算
- 💳 **支付层**：Stripe Checkout 支付 + 订单状态管理
- ⚡ **边缘层**：EdgeOne Edge Functions（KV 访问统计）+ Cloud Functions（订单 API）

---

## ⛔ 关键规则（永不跳过）

1. **先问用户配置，再动手写代码** — 按 Step 1 收集完 Spec 再开始生成
2. **技术栈固定**：React + Vite + TypeScript + Tailwind CSS，不接受更换
3. **UI 设计系统固定**（见下文 Design Token），所有组件必须严格遵守，不得自由发挥颜色
4. **AI 功能使用 Mock** — AI 生图/3D/视频/对话均为 Mock 展示，不接真实 AI API
5. **认证必须用 Supabase Auth** — 不自己实现 JWT，不用 Firebase，统一 Supabase
6. **支付必须用 Stripe** — Checkout Session 模式，密钥只在 Cloud Function 中使用，绝不暴露到前端
7. **Cloud Functions 处理所有敏感操作**（支付、订单写入），Edge Functions 处理轻量统计
8. **环境变量不得硬编码进源文件** — 全部从 `.env.local` 读取，`.env.local` 加入 `.gitignore`
9. **部署交给 edgeone-pages-deploy Skill**，本 Skill 只负责生成代码和本地验证
10. **全站响应式**，移动端优先

---

## 🎨 Design Token（设计规范，必须严格遵守）

### 色彩系统

```css
/* 基础色 */
--color-bg: #ffffff;
--color-surface: #ffffff;
--color-text-primary: #000000;
--color-text-on-dark: #ffffff;
--color-border: #000000;

/* 按钮 */
--color-btn-solid-bg: #000000;
--color-btn-solid-text: #ffffff;
--color-btn-ghost-text: #000000;

/* 微妙覆盖层 */
--overlay-card-subtle: rgba(0, 0, 0, 0.08);       /* 次级圆形按钮 / 玻璃效果暗色覆盖 */
--overlay-dark-glass: rgba(255, 255, 255, 0.16);  /* 深色/彩色表面按钮磨砂玻璃覆盖 */

/* 渐变系统 — 充满活力的多色渐变 */
--gradient-hero: linear-gradient(135deg, #00ff88 0%, #ffee00 25%, #6600ff 60%, #ff00aa 100%);
/* 电绿 → 亮黄 → 深紫 → 艳粉 */

/* 各产品域主题色（用于卡片 accent） */
--theme-image-gen:   #00ff88;   /* 电绿 — 生图 */
--theme-3d-model:    #6600ff;   /* 深紫 — 3D 模型 */
--theme-llm-chat:    #ffee00;   /* 亮黄 — 大模型交互 */
--theme-video-gen:   #ff00aa;   /* 艳粉 — 视频生成 */
--theme-audio-gen:   #00ccff;   /* 电蓝 — 音频合成（可选扩展） */
```

### 字体系统

```css
--font-family: 'figmaSans', 'figmaSans Fallback', 'SF Pro Display', system-ui, helvetica, sans-serif;
--font-weight-regular: 400;
--font-weight-medium: 500;
--font-weight-bold: 700;
```

### 圆角 & 间距

```css
--radius-card: 16px;
--radius-btn-pill: 9999px;
--radius-btn-square: 8px;
--spacing-section: 80px;
--spacing-card-gap: 24px;
```

---

## Step 1 — 收集 Spec（必须先执行）

使用 `ask_followup_question` 工具，**一次性**向用户提问：

> 在开始构建之前，帮我确认几个配置项：
>
> **Q1. 平台名称**（例如：NeuraHub / AI Universe / 星域 AI）
> **Q2. 主 Slogan**（例如："探索 AI 的无限可能"）
> **Q3. 展示的 AI 产品模块**（可多选，默认全选4个）：
>    - ✅ 生图 / ✅ 3D 模型 / ✅ 大模型交互 / ✅ 视频生成 / ⬜ 音频合成 / ⬜ 代码生成
> **Q4. 全栈功能**（可多选，默认全开）：
>    - ✅ 用户登录 / 注册（Supabase Auth）
>    - ✅ AI 能力套餐商城（商品列表 + 购物车 + 结算）
>    - ✅ 在线支付（Stripe Checkout）
>    - ✅ 订单管理页面
> **Q5. 货币 & 价格**（例如：USD，套餐价 9.9 / 29.9 / 99.9）
> **Q6. 底部版权信息**：版权归属方 + 年份
> **Q7. 友情链接**（可跳过）
>
> 如果你直接说**"默认"**，使用以下配置：
> - 名称：NeuraHub；Slogan：探索 AI 的无限可能，一站体验未来
> - 模块：生图 + 3D + 大模型 + 视频
> - 全栈功能：登录 + 商城 + Stripe 支付 + 订单
> - 货币：USD；套餐：$9.9 / $29.9 / $99.9
> - 版权：© 2025 NeuraHub. All rights reserved.

将答案汇总为 Spec 对象：

```typescript
interface PlatformSpec {
  platformName: string;
  slogan: string;
  modules: AIModule[];
  features: {
    auth: boolean;       // 登录/注册
    shop: boolean;       // 商品列表 + 购物车
    payment: boolean;    // Stripe 支付
    orders: boolean;     // 订单管理
  };
  currency: string;      // 'USD' | 'CNY'
  priceTiers: { name: string; price: number; features: string[] }[];
  copyright: string;
  friendlyLinks: { label: string; url: string }[];
}

type AIModule = 'image-gen' | '3d-model' | 'llm-chat' | 'video-gen' | 'audio-gen' | 'code-gen';
```

---

## Step 2 — 初始化项目

```bash
# 创建 Vite + React + TypeScript 项目
npm create vite@latest <platformName-kebab-case> -- --template react-ts
cd <platformName-kebab-case>

# 基础依赖
npm install
npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init -p
npm install framer-motion lucide-react clsx tailwind-merge

# 全栈依赖
npm install @supabase/supabase-js        # 认证 + 数据库
npm install @stripe/stripe-js            # Stripe 前端 SDK（仅用于跳转 Checkout）
npm install zustand                      # 购物车全局状态
npm install react-router-dom             # 路由（登录/订单/商城页面）
```

初始化后，按以下结构组织代码（见 `references/project-structure.md`）。

> ⚠️ 复制 `.env.example` → `.env.local`，填写以下变量（见 `references/auth-guide.md` 和 `references/payment-guide.md`）：
> ```
> VITE_SUPABASE_URL=
> VITE_SUPABASE_ANON_KEY=
> VITE_STRIPE_PUBLISHABLE_KEY=
> # 以下变量只用于 Cloud Function，不要以 VITE_ 前缀暴露到前端
> STRIPE_SECRET_KEY=
> SUPABASE_SERVICE_ROLE_KEY=
> ```

---

## Step 3 — 生成完整网站代码

严格按照 Design Token 和 UI 规范生成以下组件。详细代码规范见对应 references 文件。

### 路由结构（React Router）

```
/                     → 首页（展示 + 商城入口）
/login                → 登录 / 注册页
/shop                 → AI 能力套餐商城
/cart                 → 购物车
/checkout/success     → 支付成功页（Stripe 回调）
/checkout/cancel      → 支付取消页
/orders               → 我的订单（需登录）
```

### 首页（`/`）总体结构

```
<App>
  <NavBar />                    // 顶部导航：Logo + 导航链接 + 登录状态 + 购物车图标
  <HeroSection />               // 主视觉区：大标题 + Slogan + 渐变光晕
  <ProductsSection />           // AI 能力卡片区（4 大模块 + "立即购买"入口）
  <DemoSection />               // Mock 交互演示区（黑底）
  <PricingSection />            // 套餐定价区（3 档卡片 + 购买按钮）
  <StatsSection />              // 数据统计（KV 实时访问量）
  <Footer />                    // 底部版权 + 友链
</App>
```

### 各组件/页面设计要点（新增部分）

**NavBar（顶部导航）升级**：
- 新增路由导航项：Products / Shop / Demo
- 右侧区域：
  - 已登录：用户头像/昵称 + 购物车图标（显示数量徽章）+ 下拉菜单（我的订单 / 退出）
  - 未登录：「登录 / 注册」幽灵按钮 + 「开始体验」实心按钮
- 购物车徽章：`bg-black text-white` 小圆点，数字字号 10px

**PricingSection（定价区）**：
- 三列套餐卡片，居中布局
- 每张卡片：套餐名 + 价格（大字号）+ 功能列表（✓ 逐条）+ 购买按钮
- 推荐套餐（中间档）：边框加粗 `2px solid #000` + 顶部渐变 accent bar
- 购买按钮点击：若未登录 → 跳转 `/login`；已登录 → 加入购物车或直接跳 Stripe Checkout
- 见 `references/payment-guide.md`

**LoginPage（`/login`）**：
- 白底，居中卡片（max-width 400px）
- Tab 切换：登录 / 注册
- 表单字段：邮箱 + 密码（注册多一个"确认密码"）
- 「第三方登录」可选（GitHub OAuth，Supabase 支持）
- 错误提示：红色 `border-red-500` 字段高亮 + 错误文本
- 成功后跳转：回到上一页或首页
- 见 `references/auth-guide.md`

**ShopPage（`/shop`）**：
- 商品卡片网格（`grid-cols-1 md:grid-cols-3`）
- 每个商品：封面图占位 + 名称 + 描述 + 价格 + 「加入购物车」按钮
- 商品数据来自前端静态配置（`src/lib/products.ts`），无需数据库
- 见 `references/shop-guide.md`

**CartPage（`/cart`）**：
- 列表展示购物车商品（名称 + 数量 +/- 按钮 + 删除）
- 右侧汇总：小计 + 税费（Mock 10%）+ 合计
- 「去结算」按钮：调用 Cloud Function `/api/create-checkout` → 跳转 Stripe Checkout
- 见 `references/shop-guide.md`

**OrdersPage（`/orders`）**：
- 需登录鉴权（未登录自动跳 `/login`）
- 订单列表：订单号 + 商品 + 金额 + 状态（paid/pending/cancelled）+ 时间
- 数据从 Supabase `orders` 表查询（当前用户）
- 见 `references/shop-guide.md`

---

## Step 4 — 接入 EdgeOne 后端函数

### 函数目录结构

```
functions/
  api/
    stats.js              # Edge Function：KV 访问量统计（V8 运行时）
cloud-functions/
  create-checkout.js      # Cloud Function：创建 Stripe Checkout Session（Node.js）
  webhook.js              # Cloud Function：Stripe Webhook 回调，写入订单到 Supabase
  orders.js               # Cloud Function：查询当前用户订单列表
```

> **选型依据**：
> - `stats.js` 使用 **Edge Function**（V8）：只读写 KV，无 npm 依赖，超低延迟
> - `create-checkout.js` / `webhook.js` / `orders.js` 使用 **Cloud Function**（Node.js）：
>   需要 `stripe` npm 包和 `@supabase/supabase-js`，且含密钥，必须在服务端执行

### Edge Function：`functions/api/stats.js`

```javascript
export async function onRequest({ request, env }) {
  const kv = env.AI_SHOWCASE_KV;
  const cors = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Cache-Control': 'no-store',
  };
  if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });
  try {
    if (request.method === 'POST') {
      const raw = await kv.get('pageviews');
      const count = (raw ? parseInt(raw, 10) : 0) + 1;
      await kv.put('pageviews', String(count));
      return new Response(JSON.stringify({ pageviews: count }), { headers: cors });
    }
    const raw = await kv.get('pageviews');
    return new Response(JSON.stringify({ pageviews: raw ? parseInt(raw, 10) : 0 }), { headers: cors });
  } catch {
    return new Response(JSON.stringify({ pageviews: 0, fallback: true }), { headers: cors });
  }
}
```

### Cloud Function 实现

完整实现见 `references/payment-guide.md`：
- `create-checkout.js` — 接收前端购物车，调用 Stripe API 创建 Checkout Session，返回 `sessionUrl`
- `webhook.js` — 验证 Stripe Webhook 签名，`checkout.session.completed` 事件时写订单到 Supabase
- `orders.js` — 从请求头取 Supabase JWT，验证后查询 `orders` 表返回当前用户订单

> ⚠️ **KV 前置步骤**：
> 1. EdgeOne Pages 控制台 → 存储 → 新建 KV 命名空间 `AI_SHOWCASE_KV`
> 2. `edgeone pages link` 关联项目
> 3. `edgeone pages env pull` 拉取绑定到本地 `.env`

---

## Step 5 — 本地验证

```bash
# 带 Edge Functions + Cloud Functions 完整验证（推荐）
edgeone pages dev
# → 访问 http://localhost:8088

# 仅前端验证（无法测试后端函数）
npm run dev
# → 访问 http://localhost:5173
```

验证清单：

**基础展示**
- [ ] 顶部导航显示正确，响应式汉堡菜单正常
- [ ] Hero 区渐变光晕动效正常
- [ ] 产品卡片 4 张全部显示，Hover 动效正确
- [ ] Demo 区切换 Tab，Mock 交互正常
- [ ] 定价套餐 3 张卡片显示，中间卡片有推荐标识
- [ ] `/api/stats` 返回 `{ pageviews: N }`

**认证流程**
- [ ] 访问 `/login` 页面正常渲染
- [ ] 注册新账号（需 Supabase 配置），收到验证邮件
- [ ] 登录后 NavBar 显示用户信息 + 购物车图标
- [ ] 登录后访问 `/orders` 正常，未登录时自动跳转 `/login`

**购物 & 支付流程**
- [ ] 访问 `/shop` 商品列表正常
- [ ] 点击「加入购物车」，NavBar 购物车数字 +1
- [ ] 访问 `/cart` 显示已选商品，可增删
- [ ] 点击「去结算」调用 `/api/create-checkout`，跳转 Stripe 支付页（需 Stripe 测试密钥）
- [ ] Stripe 测试卡 `4242 4242 4242 4242` 支付成功，跳转 `/checkout/success`
- [ ] `/orders` 页面出现刚创建的订单

**移动端**
- [ ] 375px 宽度下所有页面布局正常

---

## Step 6 — 交接部署

检查用户是否已安装 `edgeone-pages-deploy` Skill：

**已安装** → 告知用户说：「**部署到 EdgeOne Pages**」即可触发部署流程

**未安装** → 提示用户安装，或给出手动部署命令：
```bash
npm install -g edgeone@latest
edgeone pages deploy -n <platform-name>
```

部署完成后：
1. 展示完整的 `EDGEONE_DEPLOY_URL`（含查询参数，不得截断）
2. 展示 EdgeOne Pages 控制台链接
3. 提示：如需长期稳定访问，建议在控制台绑定已备案的自定义域名

---

## 参考文档索引

| 内容 | 文件 |
|------|------|
| 项目目录结构规范 | `references/project-structure.md` |
| 各展示组件完整代码 | `references/component-guide.md` |
| Design Token 完整 CSS 变量表 | `references/design-tokens.md` |
| Mock 数据与交互动效规范 | `references/mock-interactions.md` |
| Edge Functions + KV 接入指南 | `references/edge-functions-kv.md` |
| **用户认证方案（Supabase Auth）** | `references/auth-guide.md` |
| **支付方案（Stripe + 订单流程）** | `references/payment-guide.md` |
| **购物车 + 商城 + 订单页面规范** | `references/shop-guide.md` |
